<template>
    <div>
       <Navbar></Navbar>
       <router-view></router-view>
    </div>
</template>

<script>
 import Navbar from './Navbar.vue';

    export default{
        components:{
            Navbar
        },
        data(){
            return {
                msg: "Vue"
            }
        }
    }
</script>
