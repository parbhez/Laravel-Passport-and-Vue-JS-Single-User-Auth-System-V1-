<template>
    <div>
        <h1>About Blog</h1>
    </div>
 </template>
