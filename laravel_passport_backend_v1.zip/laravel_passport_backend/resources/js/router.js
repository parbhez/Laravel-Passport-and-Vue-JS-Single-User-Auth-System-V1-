import { createRouter, createWebHistory } from 'vue-router'
import store from './store'
const routes = [{
        path: '/',
        name: 'Home',
        component: () =>
            import ('./components/pages/Home.vue'),
        meta: { requiresAuth: true }
    },

    {
        path: '/about',
        name: 'About',
        component: () =>
            import ('./components/pages/About.vue'),
        meta: { requiresAuth: true }
    },
    {
        path: '/blog',
        name: 'Blog',
        component: () =>
            import ('./components/pages/Blog.vue'),
        meta: { requiresAuth: true }
    },
    {
        path: '/login',
        name: 'Login',
        component: () =>
            import ('./components/pages/Login.vue'),
        meta: { visitor: true }
    },
    {
        path: '/register',
        name: 'Register',
        component: () =>
            import ('./components/pages/Register.vue'),
        meta: { visitor: true }
    },
    {
        path: '/logout',
        name: 'Logout',
        component: () =>
            import ('./components/pages/Logout.vue'),
        meta: { requiresAuth: true }
    },
    {
        path: '/:pathMatch(.*)*',
        //redirect: '/',
        name: 'PageNotFound',
        component: () =>
            import ('./components/common/PageNotFound.vue')
    },

]

const allRouterPath = createRouter({
    history: createWebHistory(),
    routes,
});

allRouterPath.beforeEach((to, from, next) => {
    if (to.matched.some(record => record.meta.requiresAuth)) {
        // this route requires auth, check if logged in
        // if not, redirect to login page.
        if (!store.getters.loggedIn) {
            next({
                name: "Login"
            })
        } else {
            next()
        }
    } else if (to.matched.some(record => record.meta.visitor)) {
        // this route requires auth, check if logged in
        // if logged in, redirect to Home page.
        if (store.getters.loggedIn) {
            next({
                name: "Home"
            })
        } else {
            next()
        }
    } else {
        next() // make sure to always call next()!
    }
})

export default allRouterPath