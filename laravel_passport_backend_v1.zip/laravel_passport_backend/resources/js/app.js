import './bootstrap';
import { createApp } from 'vue';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js';

import ViewUIPlus from 'view-ui-plus';
import 'view-ui-plus/dist/styles/viewuiplus.css';
//import vue-router
import router from './router';
//Import mixin
import common from './common';
import store from './store';

import MainApp from './components/MainApp.vue';

const app = createApp({});

app.component('main-app', MainApp);

app.use(router);
app.use(ViewUIPlus);
app.use(store);
app.mixin(common);
app.mount('#app')